// Mock implementation of Axios library
import mockAxios from "jest-mock-axios";
export default mockAxios;
